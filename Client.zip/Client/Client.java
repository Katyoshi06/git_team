package com.nexus.whc.models;

import javax.validation.constraints.NotBlank;


import org.apache.tomcat.jni.Time;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Map;

/*
 * Client.java
 *
 * Bean定義(M_CLIENTテーブル)
 */


public class Client {

	@NotBlank(message="顧客番号は必ず入力してください。")
	private String clientId;

	@NotBlank(message="顧客名は必ず入力してください。")
	private String clientName;

	@NotBlank(message="始業時刻は必ず入力してください。")
	private String openTime;

	@NotBlank(message="就業時刻は必ず入力してください。")
	private String closeTime;

	@NotBlank(message="作業時間は必ず入力してください。")
	private String workingTime;

	@NotBlank(message="休憩1開始は必ず入力してください。")
	private String rest1Start;

	@NotBlank(message="休憩1終了は必ず入力してください。")
	private String rest1End;
	private String rest2Start;
	private String rest2End;
	private String rest3Start;
	private String rest3End;
	private String rest4Start;
	private String rest4End;
	private String rest5Start;
	private String rest5End;
	private String rest6Start;
	private String rest6End;
	private String adjustRestTimeStart;
	private String adjustRestTimeEnd;
	private String comment;
	private Date createdAt;
	private String createdUser = "678";
	private Date updatedAt;
	private String updatedUser;


	//setter
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public void setOpenTime(String openTime) {
		this.openTime = openTime;
	}
	public void setCloseTime(String closeTime) {
		this.closeTime = closeTime;
	}
	public void setWorkingTime(String workingTime) {
		this.workingTime = workingTime;
	}
	public void setRest1Start(String rest1Start) {
		this.rest1Start = rest1Start;
	}
	public void setRest1End(String rest1End) {
		this.rest1End = rest1End;
	}
	public void setRest2Start(String rest2Start) {
		this.rest2Start = rest2Start;
	}
	public void setRest2End(String rest2End) {
		this.rest2End = rest2End;
	}
	public void setRest3Start(String rest3Start) {
		this.rest3Start = rest3Start;
	}
	public void setRest3End(String rest3End) {
		this.rest3End = rest3End;
	}
	public void setRest4Start(String rest4Start) {
		this.rest4Start = rest4Start;
	}
	public void setRest4End(String rest4End) {
		this.rest4End = rest4End;
	}
	public void setRest5Start(String rest5Start) {
		this.rest5Start = rest5Start;
	}
	public void setRest5End(String rest5End) {
		this.rest5End = rest5End;
	}
	public void setRest6Start(String rest6Start) {
		this.rest6Start = rest6Start;
	}
	public void setRest6End(String rest6End) {
		this.rest6End = rest6End;
	}
	public void setAdjustRestTimeStart(String adjustRestTimeStart) {
		this.adjustRestTimeStart = adjustRestTimeStart;
	}
	public void setAdjustRestTimeEnd(String adjustRestTimeEnd) {
		this.adjustRestTimeEnd = adjustRestTimeEnd;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public void setCreatedAt() {
		Date now = new Date();
		this.createdAt = now;
	}
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}
	public void setUpdatedAt() {
		Date now = new Date();
		this.updatedAt = now;
	}
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}

	//getter
	public String getClientId() {
		return clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public String getOpenTime() {
		return openTime;
	}
	public String getCloseTime() {
		return closeTime;
	}
	public String getWorkingTime() {
		return workingTime;
	}
	public String getRest1Start() {
		return rest1Start;
	}
	public String getRest1End() {
		return rest1End;
	}
	public String getRest2End() {
		return rest2End;
	}
	public String getRest2Start() {
		return rest2Start;
	}
	public String getRest3Start() {
		return rest3Start;
	}
	public String getRest3End() {
		return rest3End;
	}
	public String getRest4Start() {
		return rest4Start;
	}
	public String getRest4End() {
		return rest4End;
	}
	public String getRest5Start() {
		return rest5Start;
	}
	public String getRest5End() {
		return rest5End;
	}
	public String getRest6Start() {
		return rest6Start;
	}
	public String getRest6End() {
		return rest6End;
	}
	public String getAdjustRestTimeStart() {
		return adjustRestTimeStart;
	}
	public String getAdjustRestTimeEnd() {
		return adjustRestTimeEnd;
	}
	public String getComment() {
		return comment;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public String getCreatedUser() {
		return "678";
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public String getUpdatedUser() {
		return updatedUser;
	}

	//単体時間フォーマット変換
	public String registTimeFormat(String time) {
		SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
		String formattedTime = timeFormat.format(time);
		return formattedTime;
	}


	//時間フォーマット変換
	public String timeFormat(Map<String, Object> map, String key) {
		//マップ内に指定したkeyが存在するか
		if(map.containsKey(key)) {
			//keyの値を取得して変数に代入
			Object value = map.get(key);

			//valueの中身がデータ型ならフォーマットする。
			if(value instanceof Date) {
				SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
				String formattedTime = timeFormat.format(value);
				if(formattedTime.equals("00:00")) {
					map.put(key,null);
					return formattedTime;
				}
				map.put(key,formattedTime);
				return formattedTime;
				//そうでないならnullを返す
			}else {
				return null;
			}
		}
		return null;
	}
	//顧客IDフォーマット
	public boolean idFormat(String client_id) {
		if(client_id != null && client_id.matches("\\d+") && client_id.length() == 3) {
			return true;
		}
		return false;
	}

	//作業時間フォーマット
	public boolean workingTimeFormat(String workingTime) {

		if(workingTime != null && workingTime.matches("\\d{1,2}\\.\\d{1,2}")) {
			return true;
		}
		return false;
	}

	public boolean timeFormatHm(String[] inputTimes) {
	        SimpleDateFormat time = new SimpleDateFormat("HH:mm");
	        time.setLenient(false);
	        for (String inputTime : inputTimes) {
	    		System.out.println(inputTime);
	        	if(!inputTime.isEmpty() || inputTime != "") {
	            try {
	                time.parse(inputTime);
	            } catch (ParseException e) {
	                return false; // パースに失敗した場合はfalseを返す
	            }
	        	}
	        }
	        return true; // 全ての時間文字列が正しいフォーマットの場合にtrueを返す
	    }

	//全てのカラムを登録する
	public void setEntiry(Map<String, Object> clientMap) {
		this.clientId = clientMap.get("client_id").toString();
		this.clientName = clientMap.get("client_name").toString();
		this.openTime = clientMap.get("open_time").toString();
		this.closeTime = clientMap.get("close_time").toString();
		this.workingTime = clientMap.get("working_time").toString();
		this.rest1Start = clientMap.get("rest1_start").toString();
		this.rest1End = clientMap.get("rest1_end").toString();

		//nullでも可能なもの
		try {
			this.rest2Start = clientMap.get("rest2_start").toString();
		}catch(NullPointerException e) {
			System.out.println("休憩2開始がnullです。空文字に変換します。");
			this.rest2Start = "";
		}
		try {
			this.rest2End = clientMap.get("rest2_end").toString();
		}catch(NullPointerException e) {
			System.out.println("休憩2終了がnullです。空文字に変換します。");
			this.rest2End = "";
		}
		try {
			this.rest3Start = clientMap.get("rest3_start").toString();
		}catch(NullPointerException e) {
			System.out.println("休憩3開始がnullです。空文字に変換します。");
			this.rest3Start = "";
		}
		try {
			this.rest3End = clientMap.get("rest3_end").toString();
		}catch(NullPointerException e) {
			System.out.println("休憩3終了がnullです。空文字に変換します。");
			this.rest3End = "";
		}
		try {
			this.rest4Start = clientMap.get("rest4_start").toString();
		}catch(NullPointerException e) {
			System.out.println("休憩4開始がnullです。空文字に変換します。");
			this.rest4Start = "";
		}
		try {
			this.rest4End = clientMap.get("rest4_end").toString();
		}catch(NullPointerException e) {
			System.out.println("休憩4終了がnullです。空文字に変換します。");
			this.rest4End = "";
		}
		try {
			this.rest5Start = clientMap.get("rest5_start").toString();
		}catch(NullPointerException e) {
			System.out.println("休憩5開始がnullです。空文字に変換します。");
			this.rest5Start = "";
		}
		try {
			this.rest5End = clientMap.get("rest5_end").toString();
		}catch(NullPointerException e) {
			System.out.println("休憩5終了がnullです。空文字に変換します。");
			this.rest5End = "";
		}
		try {
			this.rest6Start = clientMap.get("rest6_start").toString();
		}catch(NullPointerException e) {
			System.out.println("休憩6開始がnullです。空文字に変換します。");
			this.rest6Start = "";
		}
		try {
			this.rest6End = clientMap.get("rest6_end").toString();
		}catch(NullPointerException e) {
			System.out.println("休憩6終了がnullです。空文字に変換します。");
			this.rest6End = "";
		}
		try {
			this.adjustRestTimeStart = clientMap.get("adjust_rest_time_start").toString();
		}catch(NullPointerException e) {
			System.out.println("調整休憩時間開始がnullです。空文字に変換します。");
			this.adjustRestTimeStart = "";
		}
		try {
			this.adjustRestTimeEnd = clientMap.get("adjust_rest_time_end").toString();
		}catch(NullPointerException e) {
			System.out.println("調整休憩時間終了がnullです。空文字に変換します。");
			this.adjustRestTimeEnd = "";
		}
		try {
			this.comment = clientMap.get("comment").toString();
		}catch(NullPointerException e) {
			System.out.println("コメントがnullです。空文字に変換します。");
			this.comment = "";
		}


	}


}

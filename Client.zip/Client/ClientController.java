package com.nexus.whc.controller;

import java.awt.geom.Arc2D.Double;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.nexus.whc.models.Client;
import com.nexus.whc.services.ClientService;

@Controller
@RequestMapping("/client")
public class ClientController {


	@Autowired
	ClientService clientService;

	@Autowired
	HttpSession session;

	int num = 0;

	@GetMapping("/list")
	public String clientList(@RequestParam(name = "page", defaultValue = "1") int pageNumber,
			@ModelAttribute Client client,
			Model model) {

		//ページに表示させる数
		int pageSize = 20;
		List<Map<String,Object>> list = clientService.listClients(pageNumber,pageSize);
		model.addAttribute("clientList",list);

		//ページネーション用
		//アクティブな顧客データの総数
		int totalClient = clientService.getTotalClient();
		//20件ずつ表示したときのページ数
		int totalPage = (int)Math.ceil((double)totalClient / pageSize);
		model.addAttribute("nowPageNumber",pageNumber);
		model.addAttribute("totalPage",totalPage);

		return "SMSCL001";
	}

	//キャンセル押下時
	@PostMapping("/cancel")
	public String registCancel(@ModelAttribute Client client) {
		String clientId = client.getClientId();
		String userId = client.getCreatedUser();

		//ロックの情報が残っている場合に削除
		clientService.deleteLockUser("m_client",clientId,userId);
		return "redirect:/client/list";
	}


	//検索
	@PostMapping("/search")
	public String searchList(@RequestParam(name="searchClientId",defaultValue="")String searchClientId,
			@RequestParam(name="searchClientName",defaultValue="")String searchClientName,
			@RequestParam(name = "page", defaultValue = "1") int pageNumber,
			Model model) {

		//ページに表示させる数
		int pageSize = 20;
		List<Map<String,Object>> searchList = clientService.searchClientList(searchClientId,searchClientName);
		if(searchList.isEmpty() || searchList.contains(null)) {
			model.addAttribute("searchNull",searchClientId + searchClientName + "の検索結果は0件です。条件を変更し、再度検索してください。");
		}
		model.addAttribute("searchClientId",searchClientId);
		model.addAttribute("searchClientName",searchClientName);
		model.addAttribute("searchList",searchList);

		//ページネーション用
		//アクティブな顧客データの総数
		int totalClient = searchList.size();
		//20件ずつ表示したときのページ数
		int totalPageSearch = (int)Math.ceil((double)totalClient / pageSize);
		model.addAttribute("nowPageNumber",pageNumber);
		model.addAttribute("totalPage",totalPageSearch);


		return "SMSCL001";

	}

	//登録
	@GetMapping("/regist")
	public String clientRegistGet(@RequestParam(name="clientId", defaultValue="")String clientId,
			@ModelAttribute Client client,
			RedirectAttributes attr,
			Model model) {
		String userId = client.getCreatedUser();

		//排他チェック削除（データ存在チェック）
		String result =clientService.selectClientId(clientId);

		//存在しなかった場合の処理
		if(!clientId.isEmpty()) {
			if(result == null || result.isEmpty()) {
				attr.addFlashAttribute("delete","該当データはすでに削除されています。");
				return "redirect:/client/list";
			}
		}

		//排他チェック編集中　clientIdがnullでない時
		if(!clientId.isEmpty()) {
			//編集中のクライアントIDをロック
			boolean resultLock = clientService.registLockUser(clientId, "m_client", clientId, userId);
			if(resultLock == false) {
				Map<String, Object> lockUserMap = clientService.lockUser("m_client",clientId);
				String lockUserId = (String)lockUserMap.get("user_id");
				//取得したロック情報のユーザIDとログインユーザIDが違う場合の処理
				if(!lockUserId.equals("678")) {
					String lockUserName = (String)lockUserMap.get("user_name");
					attr.addFlashAttribute("lock","該当データは他のユーザ「" + lockUserName + "」が編集中です。");
					return "redirect:/client/list";
				}
			}
		}

		//clientIdとclientNameの値で取得できるならtrue
		boolean registOrUpdate = clientService.selectClientIdName(clientId);

		client = clientService.searchClient(clientId);

		model.addAttribute("readonlyResult",registOrUpdate);
		model.addAttribute("client",client);


		return "SMSCL002";
	}
	//登録Post
	//登録押下
	@PostMapping("/regist")
	public String clientRegistPost(@Validated @ModelAttribute Client client,
			BindingResult bindingResult,
			@RequestParam(name="screenKey")String screenKey,
			Model model) {

		String clientId = client.getClientId();
		String clientName = client.getClientName();
		String workingTime = client.getWorkingTime();

		//必須チェック
		if(bindingResult.hasErrors()) {
			//登録と更新のモード分け
			boolean registOrUpdate = clientService.selectClientIdName(null);
			model.addAttribute("readonlyResult",registOrUpdate);

			return "SMSCL002";
		}

		//フォーマットチェック
		boolean formattedId = client.idFormat(clientId);
		boolean formattedTime = client.workingTimeFormat(workingTime);
		if( formattedId == false) {
			model.addAttribute("formatId","000(123など)で入力してください。");
		}
		if(formattedTime == false) {
			model.addAttribute("formatTime","0.00(1.23など)で入力してください。");
		}
		if(formattedId == false || formattedTime == false){
			//登録と更新のモード分け
			boolean registOrUpdate = clientService.selectClientIdName(null);
			model.addAttribute("readonlyResult",registOrUpdate);

			return "SMSCL002";
		}

		//登録モードチェック
		//新規登録

		//マスタ存在チェック
		String id = clientService.selectClientId(clientId);
		String name = clientService.selectClientName(clientName);

		try {
			//新規登録
			clientService.registClient(client);
			if(screenKey.equals("registKey")) {
				return "redirect:/client/list";
			}else {
				return "redirect:/client/regist";
			}
			//重複
		}catch(DuplicateKeyException e) {
			if(id == null || id.equals("") || !id.equals(clientId)) {
				model.addAttribute("duplicationName","顧客名に入力した"+clientName+"は顧客マスタにすでに存在しています。");
			}
			if(name == null || name.equals("") || !name.equals(clientName)) {
				model.addAttribute("duplicationId","顧客番号に入力した"+clientId+"は顧客マスタにすでに存在しています。");
			}
			//登録と更新のモード分け
			boolean registOrUpdate = clientService.selectClientIdName(null);
			model.addAttribute("readonlyResult",registOrUpdate);

			return "SMSCL002";
		}

	}

	//更新


	//更新押下
	@PostMapping("/edit")
	public String clientupdatePost(@Validated @ModelAttribute Client client,
			BindingResult bindingResult,
			@RequestParam(name="updateKey")String updateKey,
			RedirectAttributes attr,
			Model model) {

		String clientId = client.getClientId();
		String workingTime = client.getWorkingTime();
		String userId = client.getCreatedUser();


		//更新のモード
		boolean registOrUpdate = clientService.selectClientIdName(clientId);
		model.addAttribute("readonlyResult",registOrUpdate);

		//必須チェック
		if(bindingResult.hasErrors()) {
			return "SMSCL002";
		}

		//フォーマットチェック
		boolean formattedId = client.idFormat(clientId);
		boolean formattedTime = client.workingTimeFormat(workingTime);
		if( formattedId == false) {
			model.addAttribute("formatId","000(123など)で入力してください。");
		}
		if(formattedTime == false) {
			model.addAttribute("formatTime","0.00(1.23など)で入力してください。");
		}
		if(formattedId == false || formattedTime == false){
			return "SMSCL002";
		}

		//更新時の排他チェック（削除）
		//排他チェック削除（データ存在チェック）
		String result =clientService.selectClientId(clientId);
		//存在しなかった場合の処理
		if(!clientId.isEmpty()) {
			if(result == null || result.isEmpty()) {
				attr.addFlashAttribute("delete","該当データはすでに削除されています。");
				return "redirect:/client/list";
			}
		}

		//排他チェック編集中　clientIdがnullでない時
		if(!clientId.isEmpty()) {
			Map<String, Object> lockUserMap = clientService.lockUser("m_client",clientId);
			String lockUserId = (String)lockUserMap.get("user_id");
			//ロック情報のユーザIDと編集中のユーザIDの値が違う場合
			if(!lockUserId.equals(userId)) {
				String lockUserName = (String)lockUserMap.get("user_name");
				attr.addFlashAttribute("lock","該当データは他のユーザ「" + lockUserName + "」が編集中です。");
				return "redirect:/client/list";
			}

		}

		clientService.updateClient(client);
		//ロックを解除
		clientService.deleteLockUser("m_client",clientId,userId);


		return "redirect:/client/list";

	}

	@PostMapping("/delete")
	public String clientDelet(@RequestParam(name="check[]", defaultValue="") String[] check,
			@RequestParam(name="clientId", defaultValue="")String[] clientId,
			@ModelAttribute Client client,
			RedirectAttributes attr) {

		String userId = client.getCreatedUser();
		clientService.loginUser(userId);
		String result = "";

		//排他チェック（削除）
		for(String id : check) {
			result += clientService.selectClientId(id);
		}
		for(String id : clientId) {
			result += clientService.selectClientId(id);
		}
		if(result.contains("null")) {
			attr.addFlashAttribute("delete","該当データはすでに削除されています。");
			return "redirect:/client/list";
		}

		//リストにエラー文を格納
		ArrayList<String> errorList =new ArrayList<String>();
		for(String id: check) {
			Map<String, Object> lockUserMap = clientService.lockUser("m_client",id);
			if(lockUserMap != null) {
				String lockUserName = (String)lockUserMap.get("user_name");
				errorList.add("該当データは他のユーザ「" + lockUserName + "」が編集中です。");
			}
		}
		if(!errorList.isEmpty()) {
			attr.addFlashAttribute("errorList",errorList);
			return "redirect:/client/list";
		}

		if(check.length > 0) {
			//一覧画面から顧客削除
			clientService.deleteClient(userId,check);

		}else if(clientId.length > 0) {
			//編集画面から削除
			clientService.deleteClient(userId,clientId);
		}else {
			attr.addFlashAttribute("message", "削除する値を選択してください。");
		}

		return "redirect:/client/list";

	}

}

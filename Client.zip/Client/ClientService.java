package com.nexus.whc.services;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.nexus.whc.models.Client;
import com.nexus.whc.repository.ClientDao;

/*
 * ClientService.java
 *
 * ClientServiceクラス
 */
@Service
public class ClientService {
	private final ClientDao dao;

	@Autowired
	public ClientService(ClientDao dao) {
		this.dao = dao;
	}

	//ロックテーブルにロック情報を挿入
	public boolean registLockUser(String seq_id, String name, String record_id, String user_id) {
		boolean lock = true;
		try {
		dao.registLockUser(seq_id, name, record_id, user_id);
		lock = true;
		}catch(DuplicateKeyException e) {
			lock = false;
		}

		return lock;
	}
	//ロック情報の確認
	public Map<String,Object> lockUser(String table_name, String record_id){
		Map<String,Object> lockUserMap = null;
		try {
		lockUserMap = dao.lockUser(table_name,record_id);
		}catch(EmptyResultDataAccessException | NullPointerException e){
		}
		return lockUserMap;
	}

	//ロックテーブル情報削除
	public int deleteLockUser(String name, String record_id, String user_id) {
		int result =0;
		try {
		result += dao.deleteLockUser(name, record_id, user_id);
		}catch(EmptyResultDataAccessException | NullPointerException e) {
			result += 0;
		}
		return result;
	}

	//ログイン中のユーザーを取得
	public String loginUser(String loginUser){
		String userId = dao.loginUser(loginUser);
		return userId;
	}


	//SMSCL001での処理
	//アクティブなDBのデータ数を取得
	public int getTotalClient() {
		int totalClient = 0;
		try {
		totalClient += dao.getTotalClient();
		}catch(EmptyResultDataAccessException e) {
			totalClient = 0;
		}
		return totalClient;
	}

	//顧客一覧を抽出
	public List<Map<String, Object>> listClients(int pageNumber, int pageSize){
		Client client = new Client();

		List<Map<String,Object>> list = dao.listClients();
		int start =(pageNumber - 1) * pageSize;
		int end = Math.min(start + pageSize, list.size());

		//時間をフォーマットするメソッド。listの中のMapを取り出す
		for(Map<String, Object> map :list) {
			//keyにmap内の全てのキーをセット
			for(String key :map.keySet()) {
				//key名にrest又はtimeを含む場合にフォーマット
				if(key.contains("rest") || key.contains("time")) {
					client.timeFormat(map, key);
				}
			}
		}
		if(start >= 0 && start < list.size()) {
			return list.subList(start, end);
		}else {
			return new ArrayList<>();
		}
	}

	//指定された顧客情報を論理削除
	public int deleteClient(String updated_user, String[] client_id) {
		int result = 0;
		result += dao.deleteClient(updated_user,client_id);

		return result;
	}

	//顧客を検索するメソッド
	public List<Map<String, Object>> searchClientList(String client_id,String client_name){

		Client client = new Client();
		List<Map<String,Object>> list = dao.searchClientList(client_id, client_name);

		//時間をフォーマットするメソッド
		for(Map<String, Object> map :list) {

			//keyにmap内の全てのキーをセット
			for(String key :map.keySet()) {
				if(key.contains("rest") || key.contains("time")) {
					client.timeFormat(map, key);
				}

			}
		}

		return list;
	}

	//SMSCL002での処理
	public Client searchClient(String clientId) {
		Client client = new Client();
		try {
			Map<String, Object> clientMap = dao.searchClient(clientId);

			//時間をフォーマットするメソッド。keyにmap内の全てのキーをセット
			for(String key :clientMap.keySet()) {
				//key名にrest又はtimeを含む場合にフォーマット
				if(key.contains("rest") || key.contains("time")) {
					client.timeFormat(clientMap, key);
				}
			}

			client.setEntiry(clientMap);
		}catch(EmptyResultDataAccessException e) {
			System.out.println("新規登録画面へ遷移");
		}

		return client;
	}

	//マスタ存在チェック
	public Map<String, Object> selectClient(String client_id, String client_name){
		Map<String,Object> selectMap = dao.selectClient(client_id,client_name);

		return selectMap;
	}

	//顧客ID重複チェック
	public String selectClientId(String id) {
		String clientId = "";

		try {
			clientId = dao.selectClientId(id);
		}catch(EmptyResultDataAccessException | NullPointerException e) {
			clientId = null;
		}
		return clientId;
	}
	//顧客名重複チェック
	public String selectClientName(String name) {
		String clientName = null;
		try {
			clientName += dao.selectClientName(name);
		}catch(EmptyResultDataAccessException | NullPointerException e) {
			clientName += null;
		}
		return clientName;
	}

	//顧客IDと顧客名検索
	public boolean selectClientIdName(String client_id) {

		boolean result = true;
		try {
			dao.selectClientIdName(client_id);
			result = true;
		}catch(EmptyResultDataAccessException | NullPointerException e) {
			result = false;
		}

		return result;
	}


	//登録
	public String registClient(Client client) {

		String attributeValue = new String();

		dao.registClient(client);

		return attributeValue;
	}

	//更新
	public int updateClient(Client client) {
		int result = 0;

		//顧客情報更新
		result += dao.updateClient(client);

		return result;
	}


}

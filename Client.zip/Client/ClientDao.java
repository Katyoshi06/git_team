package com.nexus.whc.repository;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nexus.whc.models.Client;

/*
 * ClientRepository.java
 *
 * ClientRepositoryクラス
 */

@Repository
public class ClientDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	//共通箇所
	//ロックテーブルにロック情報を挿入
	public int registLockUser(String seq_id, String name, String record_id, String user_id) {
		//SQL文
		String sql ="INSERT INTO s_lock (seq_id, locking_table_name, locking_record_id, locking_user_id) "
				+ "VALUES (?, ?, ?, ?)";

		//?の箇所を置換
		Object[] param = {seq_id,name,record_id,user_id};

		//クエリ実行
		int registLock = jdbcTemplate.update(sql,param);

		return registLock;
	}
	//ロック情報の確認
	public Map<String,Object> lockUser(String table_name, String record_id){
		//SQL文
		String sql = "SELECT * FROM s_lock "
				+ "INNER JOIN m_user ON s_lock.locking_user_id = m_user.user_id "
				+ "INNER JOIN m_client ON s_lock.locking_record_id = m_client.client_id "
				+ "WHERE locking_table_name=? AND locking_record_id=?";

		//?の箇所を置換
		Object[] param = {table_name, record_id};

		//クエリ実行
		Map<String,Object> lockUser = jdbcTemplate.queryForMap(sql,param);

		return lockUser;
	}

	//ロックテーブルのロック情報を削除（ロックの解除）
	public int deleteLockUser(String name, String record_id, String user_id) {
		//SQL文
		String sql ="DELETE FROM s_lock WHERE locking_table_name=? "
				+ "AND locking_record_id=? AND locking_user_id =?";

		//?の箇所を置換
		Object[] param = {name,record_id,user_id};

		//クエリ実行
		int deleteLock = jdbcTemplate.update(sql,param);

		return deleteLock;
	}


	//ログイン中のユーザを取得するmethod
	public String loginUser(String loginUser) {
		//SQL文
		String sql = "SELECT user_id FROM s_login WHERE user_id=?";

		//?の箇所を置換
		Object[] param = {loginUser};

		//クエリ実行
		String userId = jdbcTemplate.queryForObject(sql,param,String.class);

		return userId;
	}


	//SMSCL001での処理
	//アクティブなDBのデータ数を取得する
	public int getTotalClient() {

		//SQL文作成
		String sql = "SELECT COUNT(*) FROM m_client WHERE delete_flg != 'true'";

		//クエリ実行
		int totalClient = jdbcTemplate.queryForObject(sql, Integer.class);

		//取得した件数を返す
		return totalClient;
	}

	//顧客マスタからアクティブな顧客情報を取得して一覧で返すメソッド
	public List<Map<String, Object>> listClients(){

		//SQL文作成
		String sql = "SELECT * FROM m_client WHERE delete_flg != 'true'";


		//クエリ実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);

		//取得したリストを返す
		return list;

	}

	//顧客一覧から選択した値を削除するメソッド
	public int deleteClient(String updated_user, String[] client_id) {

		int result = 0;

		for(String id:client_id) {

			//SQL文
			String sql = "UPDATE m_client SET delete_flg =?, updated_at=?, updated_user=? WHERE client_id=?";

			Date time = new Date();

			//?の箇所を置換
			Object[] param = {false,time,updated_user,id};

			//クエリ実行
			result += jdbcTemplate.update(sql, param);
		}

		return result;
	}


	//顧客を検索するメソッド
	public List<Map<String,Object>> searchClientList(String client_id,String client_name){

		//SQL文作成
		String sql = "SELECT * FROM m_client WHERE delete_flg != 'true' ";
		Object[] param = null;
		if(!client_id.isEmpty() && !client_name.isEmpty()) {
			sql += "AND client_id LIKE ? AND client_name LIKE ? ";
			param = new Object[]{"%" + client_id + "%", "%" + client_name + "%"};
		}else if(client_name.isEmpty() && !client_id.isEmpty()) {
			sql += "AND client_id LIKE ? ";
			param =  new Object[] {"%" + client_id + "%"};
		}else if(!client_name.isEmpty() && client_id.isEmpty()){
			sql += "AND client_name LIKE ? ";
			param =  new Object[] {"%" + client_name + "%"};
		}else {

		}


		//クエリ実行
		List<Map<String,Object>> list = jdbcTemplate.queryForList(sql,param);

		return list;
	}

	//SMSCL002での処理
	//指定された顧客情報を取得するメソッド
	public Map<String, Object> searchClient(String client_id){

		//SQL文
		String sql = "SELECT * FROM m_client WHERE client_id =? "
				+ "AND delete_flg != 0";

		//?の箇所を置換
		Object[] id = {client_id};

		//クエリ実行
		Map<String, Object> map = jdbcTemplate.queryForMap(sql, id);

		//顧客情報を返す
		return map;
	}

	//入力された顧客ID及び顧客名のマスタが存在するか
	//マスタ存在チェック用顧客マスタテーブル検索
	public Map<String, Object> selectClient(String client_id, String client_name){

		//SQL文
		String sql = "SELECT client_id, client_name FROM m_client "
				+ "WHERE client_id = ? "
				+ "AND client_name = ? "
				+ "AND delete_flg = false";

		//?の箇所を置換
		Object[] param = {client_id,client_name};

		//クエリ実行
		Map<String, Object> selectMap = jdbcTemplate.queryForMap(sql,param);

		return selectMap;

	}

	//入力された顧客IDのマスタが存在するか
	//マスタ存在チェック用顧客マスタテーブル検索
	public String selectClientId(String client_id){

		//SQL文
		String sql = "SELECT client_id FROM m_client "
				+ "WHERE client_id = ? "
				+ "AND delete_flg != 0";

		//?の箇所を置換
		Object[] param = {client_id};

		//クエリ実行
		String selectid = jdbcTemplate.queryForObject(sql,String.class, param);

		return selectid;

	}
	//入力された顧客名のマスタが存在するか
	//マスタ存在チェック用顧客マスタテーブル検索
	public String selectClientName(String client_name){

		//SQL文
		String sql = "SELECT client_name FROM m_client "
				+ "WHERE client_name = ? "
				+ "AND delete_flg != false";

		//?の箇所を置換
		Object[] param = {client_name};

		//クエリ実行
		String selectname = jdbcTemplate.queryForObject(sql,String.class, param);

		return selectname;

	}
	//入力された顧客IDと顧客名のマスタが存在するか
	public String selectClientIdName(String client_id){

		//SQL文
		String sql = "SELECT client_id FROM m_client "
				+ "WHERE client_id = ? "
				+ "AND delete_flg != false";

		//?の箇所を置換
		Object[] param = {client_id};

		//クエリ実行
		String selectname = jdbcTemplate.queryForObject(sql,String.class, param);

		return selectname;

	}

	//顧客情報を登録するメソッド
	public int registClient(Client client) {

		// SQL文
		String sql = "INSERT INTO m_client(client_id, client_name, open_time, close_time,"
				+ " working_time, rest1_start, rest1_end, rest2_start, rest2_end,"
				+ " rest3_start, rest3_end, rest4_start, rest4_end, rest5_start,"
				+ " rest5_end, rest6_start, rest6_end, adjust_rest_time_start,"
				+ " adjust_rest_time_end, comment, delete_flg, created_at,"
				+ " created_user, updated_at, updated_user) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, true, ?, ?, ?, ?)";

		// クエリのパラメータをセット
		Object[] params = {
				client.getClientId(),
				client.getClientName(),
				client.getOpenTime(),
				client.getCloseTime(),
				client.getWorkingTime(),
				client.getRest1Start(),
				client.getRest1End(),
				client.getRest2Start(),
				client.getRest2End(),
				client.getRest3Start(),
				client.getRest3End(),
				client.getRest4Start(),
				client.getRest4End(),
				client.getRest5Start(),
				client.getRest5End(),
				client.getRest6Start(),
				client.getRest6End(),
				client.getAdjustRestTimeStart(),
				client.getAdjustRestTimeEnd(),
				client.getComment(),
				client.getCreatedAt(),
				client.getCreatedUser(),
				client.getUpdatedAt(),
				client.getUpdatedUser()
		};

		// クエリ実行
		int result = jdbcTemplate.update(sql, params);

		// 登録件数を返す
		return result;
	}

	//顧客情報を編集するメソッド
	public int updateClient(Client client) {

		//SQL文
		String sql = "UPDATE m_client SET open_time=?, close_time=?, working_time=?, rest1_start=?, rest1_end=?, "
				+ "rest2_start=?, rest2_end=?, rest3_start=?, rest3_end=?, rest4_start=?, rest4_end=?, rest5_start=?, rest5_end=?, "
				+ "rest6_start=?, rest6_end=?, adjust_rest_time_start=?, adjust_rest_time_end=?, comment=?, created_at=?, "
				+ "created_user=?, updated_at=?, updated_user=? "
				+ "WHERE client_id=?";

		//?の箇所を置換
		Object[] param = {client.getOpenTime(),client.getCloseTime(),client.getWorkingTime(),client.getRest1Start(),
				client.getRest1End(),client.getRest2Start(),client.getRest2End(),client.getRest3Start(),client.getRest3End()
				,client.getRest4Start(),client.getRest4End(),client.getRest5Start(),client.getRest5End(),client.getRest6Start(),client.getRest6End(),
				client.getAdjustRestTimeStart(),client.getAdjustRestTimeEnd(),client.getComment(),client.getCreatedAt(),
				client.getCreatedUser(),client.getUpdatedAt(),client.getUpdatedUser(),client.getClientId()};
		//クエリ実行
		int result = jdbcTemplate.update(sql,param);

		return result;
	}
}

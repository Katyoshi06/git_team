package com.nexus.whc.repository;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nexus.whc.models.CalendarData;
import com.nexus.whc.models.CalendarListParam;

@Repository
public class CalendarDao {
	private final JdbcTemplate jdbcTemplate;

	@Autowired
	public CalendarDao(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<Map<String, Object>> getAllCalendar() {

		// SQL文作成
		String sql = "SELECT m_calendar.seq_id, m_calendar.client_id, m_calendar.employee_id, m_calendar.`year_month`, "
				+ "monthly_holidays, m_calendar.monthly_prescribed_days, m_calendar.`comment`, "
				+ "m_calendar.created_at, m_calendar.created_user, m_calendar.updated_at, m_calendar.updated_user, "
				+ "m_client.client_name, m_employee.employee_id, m_employee.employee_name "
				+ "from m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE m_calendar.delete_flg != 1";

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);

		// 取得したリストを返す
		return list;
	}

	public List<Map<String, Object>> getCalendar20(Integer start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}

	/*
	 * 引数　　　（int）年度（2024　→　2024/04/01～2025/03/31）
	 * 戻り値　　（int）年間休日数　
	 * 
	 */
	public int getholidaysInTheYear(int year, int clientId, Integer employeeId) {

		String startDate = String.valueOf(year) + "-04-01";
		String endDate = String.valueOf(year + 1) + "-03-31";
		int result = 0;
		List<Map<String, Object>> list = null;

		if (employeeId != null) {
			String sql = "SELECT * from m_calendar "
					+ "WHERE client_id = ? "
					+ "AND employee_id = ? "
					+ "AND m_calendar.`year_month` BETWEEN ? AND ? "
					+ "AND delete_flg != 1;";

			Object[] param = { clientId, employeeId, startDate, endDate };

			// クエリを実行
			list = jdbcTemplate.queryForList(sql, param);

		} else {

			// SQL文作成
			String sql = "SELECT * from m_calendar "
					+ "WHERE client_id = ? "
					+ "AND employee_id IS NULL "
					+ "AND m_calendar.`year_month` BETWEEN ? AND ? "
					+ "AND delete_flg != 1;";

			//?の箇所を置換するデータの配列を定義
			Object[] paramNull = { clientId, startDate, endDate };

			list = jdbcTemplate.queryForList(sql, paramNull);

		}

		for (Map<String, Object> calendarMap : list) {
			if (calendarMap.get("monthly_holidays") != null) {
				result += (int) calendarMap.get("monthly_holidays");

			}
		}

		// 取得した年間休日数を返す
		return result;
	}

	public List<Map<String, Object>> getCalendarTargetYearMonthParam(Integer clientId, Integer employeeId,
			String yearMonth) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.`comment` AS 'comment_in_year', m_calendar_detail.`comment` AS 'comment_in_day', "
				+ "m_calendar_detail.`seq_id` AS 'detail_seq_id' "
				+ "FROM m_calendar LEFT JOIN m_calendar_detail "
				+ "ON m_calendar.seq_id = m_calendar_detail.parent_seq_id "
				+ "WHERE client_id = ? "
				+ "AND ( employee_id = ? OR employee_id IS NULL ) "
				+ "AND m_calendar.`year_month` = ?";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { clientId, employeeId, yearMonth };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したマップを返す
		return list;
	}

	public Map<String, Object> getCalendarDetailYearMonth(Integer parentSeqId, String YearMonthDay) {

		// SQL文作成
		String sql = "SELECT * "
				+ "FROM m_calendar_detail "
				+ "WHERE parent_seq_id = ? "
				+ "AND m_calendar_detail.date = ? ";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { parentSeqId, YearMonthDay };

		// クエリを実行
		Map<String, Object> calendarDetailMap = jdbcTemplate.queryForMap(sql, param);

		// 取得したマップを返す
		return calendarDetailMap;
	}

	public Map<String, Object> searchCalendar(String yearMonth, Integer clientId, Integer employeeId) {

		// SQL文作成
		String sql = "SELECT * FROM m_calendar "
				+ "WHERE m_calendar.`year_month` = ? "
				+ "AND client_id = ? "
				+ "AND ( employee_id = ? OR employee_id IS NULL ) "
				+ "AND delete_flg != 1";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { yearMonth, clientId, employeeId };

		Map<String, Object> map = null;
		try {
			// クエリを実行
			map = jdbcTemplate.queryForMap(sql, param);
		} catch (EmptyResultDataAccessException e) {
			//エラーが起きたらスキップ
		}

		return map;
	}

	public Map<String, Object> searchCalendar(Integer seqId) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE m_calendar.seq_id = ? "
				+ "AND m_calendar.delete_flg != 1 ";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { seqId };

		Map<String, Object> map = null;
		try {
			// クエリを実行
			map = jdbcTemplate.queryForMap(sql, param);
		} catch (EmptyResultDataAccessException e) {
			//エラーが起きたらスキップ
		}

		return map;
	}

	//	public Map<String, Object> searchCalendarDetail(Integer parentSeqId, CalendarData calendarData) {
	//
	//		//桁数調整
	//		String date = String.format("%02d", calendarData.getDay());
	//
	//		// SQL文作成
	//		String sql = "SELECT * FROM m_calendar_detail "
	//				+ "WHERE parent_seq_id = ? "
	//				+ "AND m_calendar_detail.date = ?"
	//				+ "AND delete_flg != 1";
	//
	//		//?の箇所を置換するデータの配列を定義
	//		Object[] param = { parentSeqId, date };
	//
	//		Map<String, Object> map = null;
	//
	//		// クエリを実行
	//		map = jdbcTemplate.queryForMap(sql, param);
	//
	//		return map;
	//	}

	public void registCalendar(CalendarListParam calendarListParam, Integer clientId, int monthlyHolidays,
			String createdUser, String updatedUser) {

		String comment = calendarListParam.getAllYearRoundComment();
		String strYear = calendarListParam.getCalendarYear();
		String strMonth = calendarListParam.getCalendarMonth();
		Integer employeeId = calendarListParam.getEmployeeId();
		String strYearMonthDay = strYear + "-" + strMonth + "-01";

		int intMonth = Integer.parseInt(strMonth);
		int intYear = Integer.parseInt(strYear);
		int[] monthIndex = new int[] { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31, 29 };
		int monthlyPrescribedDays = monthIndex[intMonth];

		if (intMonth == 2 && intYear % 4 == 0) {
			monthlyPrescribedDays = monthIndex[13];
		}

		monthlyPrescribedDays -= monthlyHolidays;

		// SQL文作成
		String sql = "INSERT INTO m_calendar ( client_id, employee_id, m_calendar.`year_month`, monthly_Holidays, comment, "
				+ "monthly_prescribed_days, delete_flg, created_user, updated_user) VALUES "
				+ "(?, ?, ?, ?, ?, ?, ?, ?, ?)";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { clientId, employeeId, strYearMonthDay, monthlyHolidays, comment, monthlyPrescribedDays,
				false, "nexus01", "nexus01" };

		// クエリを実行
		int result = jdbcTemplate.update(sql, param);

	}

	public void registCalendarDetail(Integer parentSeqId, CalendarData calendarData, String yearMonth,
			String createdUser, String updatedUser) {

		//桁数調整
		String date = String.format("%02d", calendarData.getDay());

		// SQL文作成
		String sql = "INSERT INTO m_calendar_detail ( parent_seq_id, date, holiday_flg, comment, delete_flg, "
				+ "created_user, updated_user) VALUES "
				+ "(?, ?, ?, ?, ?, ?, ?)";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { parentSeqId, yearMonth + "-" + date, calendarData.isHolidayFlg(),
				calendarData.getComment(), false, "nexus01", "nexus01" };

		// クエリを実行
		int result = jdbcTemplate.update(sql, param);

	}

	public int getMaxParentId() {

		int result = 0;

		String sql = "SELECT MAX( seq_id ) AS 'max' FROM m_calendar WHERE delete_flg != 1";

		Map<String, Object> map = jdbcTemplate.queryForMap(sql);

		result = (Integer) map.get("max");

		return result;
	}

	/**
	 * 指定されたカレンダーを論理削除するSQLを実行する
	 *
	 */
	public int deleteCalendar(String[] calendarSeqIdIndex, String updatedUser) {
		// 削除した件数
		int result = 0;

		// 処理
		for (String calendarSeqId : calendarSeqIdIndex) {

			// SQL文作成
			String sql = "UPDATE m_calendar SET delete_flg = 1, updated_user = ? WHERE seq_id = ?";

			// ？の箇所を置換するデータの配列を定義
			Object[] param = { updatedUser, calendarSeqId };

			// クエリを実行
			result += jdbcTemplate.update(sql, param);
		}

		// 実行件数を返す
		return result;
	}

	/**
	 * 指定されたカレンダーを更新するSQLを実行する
	 *
	 */
	public void updateCalendar(CalendarListParam calendarListParam, int monthlyHolidays, String updatedUser) {

		Integer parentSeqId = calendarListParam.getCalendarSeqId();
		String comment = calendarListParam.getAllYearRoundComment();
		String strYear = calendarListParam.getCalendarYear();
		String strMonth = calendarListParam.getCalendarMonth();

		int intMonth = Integer.parseInt(strMonth);
		int intYear = Integer.parseInt(strYear);
		int[] monthIndex = new int[] { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31, 29 };
		int monthlyPrescribedDays = monthIndex[intMonth];

		if (intMonth == 2 && intYear % 4 == 0) {
			monthlyPrescribedDays = monthIndex[13];
		}

		monthlyPrescribedDays -= monthlyHolidays;

		// SQL文作成
		String sql = "UPDATE m_calendar SET monthly_holidays = ?, monthly_prescribed_days = ?, "
				+ "comment = ?, updated_user = ? "
				+ "WHERE seq_id = ?";

		// ？の箇所を置換するデータの配列を定義
		Object[] param = { monthlyHolidays, monthlyPrescribedDays, comment, updatedUser, parentSeqId };

		// クエリを実行
		int result = jdbcTemplate.update(sql, param);

	}

	//カレンダー詳細登録
	public void updateCalendarDetail(CalendarData calendarData, Integer parentSeqId, String yearMonth,
			String updatedUser) {

		//桁数調整
		String date = String.format("%02d", calendarData.getDay());

		// SQL文作成
		String sql = "UPDATE m_calendar_detail SET holiday_flg = ?, comment = ?, updated_user = ? "
				+ "WHERE parent_seq_id = ? AND m_calendar_detail.date = ?";

		// ？の箇所を置換するデータの配列を定義
		Object[] param = { calendarData.isHolidayFlg(), calendarData.getComment(), updatedUser, parentSeqId,
				yearMonth + "-" + date };

		jdbcTemplate.update(sql, param);

	}

	//顧客検索
	public Map<String, Object> searchClient(String clientName) {

		// SQL文作成
		String sql = "SELECT * FROM m_client "
				+ "WHERE client_name = ? "
				+ "AND delete_flg != 1";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { clientName };

		Map<String, Object> map = null;
		try {
			// クエリを実行
			map = jdbcTemplate.queryForMap(sql, param);
		} catch (EmptyResultDataAccessException e) {
			//エラーが起きたらスキップ
		}

		return map;
	}

	//社員検索
	public Map<String, Object> searchEmployee(Integer employeeId, String employeeName) {

		// SQL文作成
		String sql = "SELECT * FROM m_employee "
				+ "WHERE employee_id = ? "
				+ "AND employee_name = ?"
				+ "AND delete_flg != 1";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { employeeId, employeeName };

		Map<String, Object> map = null;
		try {
			// クエリを実行
			map = jdbcTemplate.queryForMap(sql, param);
		} catch (EmptyResultDataAccessException e) {
			//エラーが起きたらスキップ
		}

		return map;
	}

	public List<Map<String, Object>> getSearchCalendarList1(Integer employeeId, String employeeName,
			String clientName, String searchStartYearMonth, String searchEndYearMonth, int start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE m_calendar.employee_id = ? "
				+ "AND employee_name = ? "
				+ "AND client_name = ? "
				+ "AND m_calendar.year_month BETWEEN ? AND ? "
				+ "AND m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { employeeId, employeeName, clientName, searchStartYearMonth, searchEndYearMonth, start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList2(Integer employeeId, String employeeName,
			String clientName, String searchStartYearMonth, int start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE m_calendar.employee_id = ? "
				+ "AND employee_name = ? "
				+ "AND client_name = ? "
				+ "AND m_calendar.year_month >= ? "
				+ "AND m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { employeeId, employeeName, clientName, searchStartYearMonth, start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList3(Integer employeeId, String employeeName,
			String clientName, String searchEndYearMonth, int start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE m_calendar.employee_id = ? "
				+ "AND employee_name = ? "
				+ "AND client_name = ? "
				+ "AND m_calendar.year_month <= ? "
				+ "AND m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { employeeId, employeeName, clientName, searchEndYearMonth, start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList4(Integer employeeId, String employeeName,
			String searchStartYearMonth, String searchEndYearMonth, int start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE m_calendar.employee_id = ? "
				+ "AND employee_name = ? "
				+ "AND m_calendar.year_month BETWEEN ? AND ? "
				+ "AND m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { employeeId, employeeName, searchStartYearMonth, searchEndYearMonth, start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList5(Integer employeeId, String employeeName,
			String clientName, int start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE m_calendar.employee_id = ? "
				+ "AND employee_name = ? "
				+ "AND client_name = ? "
				+ "AND m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { employeeId, employeeName, clientName, start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList6(Integer employeeId, String employeeName,
			String searchStartYearMonth, int start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE m_calendar.employee_id = ? "
				+ "AND employee_name = ? "
				+ "AND m_calendar.year_month >= ? "
				+ "AND m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { employeeId, employeeName, searchStartYearMonth, start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList7(Integer employeeId, String employeeName,
			String searchEndYearMonth, int start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE m_calendar.employee_id = ? "
				+ "AND employee_name = ? "
				+ "AND m_calendar.year_month <= ? "
				+ "AND m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { employeeId, employeeName, searchEndYearMonth, start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList8(Integer employeeId, String employeeName,
			int start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE m_calendar.employee_id = ? "
				+ "AND employee_name = ? "
				+ "AND m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { employeeId, employeeName, start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList9(String clientName, String searchStartYearMonth,
			String searchEndYearMonth, int start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE client_name = ? "
				+ "AND m_calendar.year_month BETWEEN ? AND ? "
				+ "AND m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { clientName, searchStartYearMonth, searchEndYearMonth, start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList10(String clientName, String searchStartYearMonth,
			int start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE client_name = ? "
				+ "AND m_calendar.year_month >= ? "
				+ "AND m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { clientName, searchStartYearMonth, start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList11(String clientName, String searchEndYearMonth,
			int start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE client_name = ? "
				+ "AND m_calendar.year_month <= ? "
				+ "AND m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { clientName, searchEndYearMonth, start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList12(String clientName, int start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE client_name = ? "
				+ "AND m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { clientName, start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList13(String searchStartYearMonth, String searchEndYearMonth,
			int start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE m_calendar.year_month BETWEEN ? AND ? "
				+ "AND m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { searchStartYearMonth, searchEndYearMonth, start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList14(String searchStartYearMonth, int start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE m_calendar.year_month >= ? "
				+ "AND m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { searchStartYearMonth, start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList15(String searchEndYearMonth, int start) {

		// SQL文作成
		String sql = "SELECT *, m_calendar.seq_id AS 'calendar_seq_id', "
				+ "m_calendar.comment AS 'year_comment' "
				+ "FROM m_calendar LEFT JOIN m_client ON m_calendar.client_id = m_client.client_id "
				+ "LEFT JOIN m_employee ON m_calendar.employee_id = m_employee.employee_id "
				+ "WHERE m_calendar.year_month <= ? "
				+ "AND m_calendar.delete_flg != 1 "
				+ "LIMIT ?, 20";

		//?の箇所を置換するデータの配列を定義
		Object[] param = { searchEndYearMonth, start };

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, param);

		// 取得したリストを返す
		return list;
	}
}

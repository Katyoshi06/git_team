package com.nexus.whc.services;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.nexus.whc.models.CalendarData;
import com.nexus.whc.models.CalendarListParam;
import com.nexus.whc.repository.CalendarDao;

/*
 * Serviceクラス
 */
@Service
public class CalendarService {
	private final CalendarDao calendarDao;

	public CalendarService(CalendarDao calendarDao) {

		this.calendarDao = calendarDao;

	}

	public List<Map<String, Object>> getAllCalendar() {

		List<Map<String, Object>> list = calendarDao.getAllCalendar();

		for (Map<String, Object> calendarMap : list) {

			String strYear = calendarMap.get("year_month").toString();
			strYear = strYear.substring(0, strYear.indexOf("-"));
			int calendarYear = Integer.parseInt(strYear);
			int clientId = (int) calendarMap.get("client_id");
			Integer employeeId = null;
			if (calendarMap.get("employee_id") != null) {
				employeeId = (int) calendarMap.get("employee_id");
			}

			Timestamp timestampCreate = (Timestamp) calendarMap.get("created_at");
			Timestamp timestampUpdate = (Timestamp) calendarMap.get("updated_at");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
			String strCreatedAt = sdf.format(timestampCreate);
			String strUpdatedAt = sdf.format(timestampCreate);

			calendarMap.put("holidaysInTheYear", calendarDao.getholidaysInTheYear(calendarYear, clientId, employeeId));
			calendarMap.put("strCreatedAt", strCreatedAt);
			calendarMap.put("strUpdatedAt", strUpdatedAt);

		}

		/*
		//return用list
		List<CalendarForm> list = new ArrayList<CalendarForm>();
		//JDBCテンプレートから出力した全件取得List
		List<Map<String, Object>> beforeList = calendarDao.getAllCalendar();
		
		Map<Integer, Integer> hashMap = new HashMap<Integer, Integer>();
		
		//全件抽出したlistの要素数分だけループ。
		for (Map<String, Object> map : beforeList) {
		
			//List代入用CalendarForm
			CalendarForm calendarForm = new CalendarForm();
		
			//テーブルのカラム数分だけループ
			for (String key : map.keySet()) {
		
				try {
		
					//switch文でMapの中身をCalendarFormへ詰め替えをおこなう。
					switch (key) {
		
					case "seq_id":
						int seqId = (int) map.get(key);
						calendarForm.setSeqId(seqId);
						break;
		
					case "client_id":
						int clientId = (int) map.get(key);
						calendarForm.setClientId(clientId);
						break;
		
					case "client_name":
						String clientName = map.get(key).toString();
						calendarForm.setClientName(clientName);
						break;
		
					case "employee_id":
						//nullが入りうるのでIntegerで宣言
						Integer employeeId = (int) map.get(key);
						calendarForm.setEmployeeId(employeeId);
						break;
		
					case "employee_name":
						String employeeName = map.get(key).toString();
						calendarForm.setEmployeeName(employeeName);
						;
						break;
		
					case "year_month":
						//年をフォームにセット
						String strYear = map.get(key).toString();
						strYear = strYear.substring(0, strYear.indexOf("-"));
						int calendarYear = Integer.parseInt(strYear);
						calendarForm.setCalendarYear(calendarYear);
		
						//年間休日数
						clientId = calendarForm.getClientId();
						employeeId = calendarForm.getEmployeeId();
						calendarForm.setHolidaysInTheYear(
								calendarDao.getholidaysInTheYear(calendarYear, clientId, employeeId));
						break;
		
					case "monthly_holidays":
						int monthlyHolidays = (int) map.get(key);
						calendarForm.setCalendarYear(monthlyHolidays);
						break;
		
					case "monthly_prescribed_days":
						int monthlyPrescribedDays = (int) map.get(key);
						calendarForm.setCalendarYear(monthlyPrescribedDays);
						break;
		
					case "comment":
						String comment = map.get(key).toString();
						calendarForm.setEmployeeName(comment);
						;
						break;
		
					case "created_at":
						Timestamp createdAtTimestamp = (Timestamp) map.get(key);
						Date createdAt = new Date(createdAtTimestamp.getTime());
						calendarForm.setCreatedAt(createdAt);
						break;
		
					case "created_user":
						String createdUser = map.get(key).toString();
						calendarForm.setCreatedUser(createdUser);
						break;
		
					case "updated_at":
						Timestamp updatedAtTimestamp = (Timestamp) map.get(key);
						Date updatedAt = new Date(updatedAtTimestamp.getTime());
						calendarForm.setUpdatedAt(updatedAt);
						break;
		
					case "updated_user":
						String updatedUser = map.get(key).toString();
						calendarForm.setUpdatedUser(updatedUser);
						break;
		
					}
		
				} catch (NullPointerException e) {
					//nullを検知したらこのループを抜けるためだけのコード。なので処理なし。
				}
			}
		
		}
		*/
		return list;

	}

	public List<Map<String, Object>> getCalendar20(Integer start) {

		List<Map<String, Object>> list = calendarDao.getCalendar20(start);

		list = getEntityList(list);

		return list;
	}

	//一覧表示用詰め替えメソッド
	public List<Map<String, Object>> getEntityList(List<Map<String, Object>> list) {

		for (Map<String, Object> calendarMap : list) {

			String strYear = calendarMap.get("year_month").toString();
			strYear = strYear.substring(0, strYear.indexOf("-"));
			int calendarYear = Integer.parseInt(strYear);
			int clientId = (int) calendarMap.get("client_id");
			Integer employeeId = null;
			if (calendarMap.get("employee_id") != null) {
				employeeId = (int) calendarMap.get("employee_id");
			}

			Timestamp timestampCreate = (Timestamp) calendarMap.get("created_at");
			Timestamp timestampUpdate = (Timestamp) calendarMap.get("updated_at");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
			String strCreatedAt = sdf.format(timestampCreate);
			String strUpdatedAt = sdf.format(timestampUpdate);

			calendarMap.put("holidaysInTheYear", calendarDao.getholidaysInTheYear(calendarYear, clientId, employeeId));
			calendarMap.put("strCreatedAt", strCreatedAt);
			calendarMap.put("strUpdatedAt", strUpdatedAt);
		}
		return list;
	}

	public List<CalendarData> getCalendarTargetYearMonthparam3(Integer clientId, Integer employeeId, String yearMonth) {

		List<Map<String, Object>> beforeList = calendarDao.getCalendarTargetYearMonthParam(clientId, employeeId,
				yearMonth);
		List<CalendarData> calendarList = settingCalendarDataList(beforeList);
		settingCalendar(yearMonth, calendarList);

		return calendarList;
	}

	//List<CalendarData>への詰め替えメソッド　処理が重複するので別メソッドを用意
	public List<CalendarData> settingCalendarDataList(List<Map<String, Object>> beforeList) {

		List<CalendarData> calendarList = new ArrayList<CalendarData>();

		for (int i = 0; i < beforeList.size(); i++) {

			CalendarData calendarData = new CalendarData();
			Map<String, Object> map = beforeList.get(i);

			for (String key : map.keySet()) {

				try {

					//switch文でMapの中身をCalendarFormへ詰め替えをおこなう。
					switch (key) {

					case "detail_seq_id":
						int seqId = (int) map.get(key);
						calendarData.setSeqId(seqId);
						break;

					case "year_month":
						//年をフォームにセット
						String strYearMonth = map.get(key).toString();
						String strDay = strYearMonth.substring(strYearMonth.length() - 2, strYearMonth.length());
						int day = Integer.parseInt(strDay) + i;
						calendarData.setDay(day);
						break;

					case "holiday_flg":
						boolean holidayFlg = (boolean) map.get(key);
						calendarData.setHolidayFlg(holidayFlg);
						break;

					case "comment_in_day":
						String comment = map.get(key).toString();
						calendarData.setComment(comment);
						break;

					}

				} catch (NullPointerException e) {
					//nullを検知したらこのループを抜けるためだけのコード。なので処理なし。
				}
			}

			//Listに追加
			calendarList.add(calendarData);

		}

		return calendarList;

	}

	//カレンダーの表示開始位置の調整を行う。
	public List<CalendarData> settingCalendar(String yearMonth, List<CalendarData> calendarList) {

		//空カレンダー
		CalendarData blankCalendar = new CalendarData();
		//フォーマッター
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
		//基準日（月初日）
		Date referenceDate = null;
		try {
			referenceDate = sf.parse(yearMonth);
		} catch (Exception e) {
			//例外は基本起きない想定
		}
		Calendar cal = Calendar.getInstance();
		// Dateをカレンダーへ
		cal.setTime(referenceDate);

		//カレンダー表示時の補正値 (1始まりのため、-1する)
		int correctionValue = cal.get(Calendar.DAY_OF_WEEK) - 1;

		//カレンダーの表示終了位置
		int calendarEndDay = 42; //7×6＝42行
		//補正値が5未満は終了位置は35（5行）とする。
		if (correctionValue < 5) {
			calendarEndDay = 35;
		}

		for (int i = 0; i < correctionValue; i++) {

			calendarList.add(0, blankCalendar);
		}

		for (int i = calendarList.size(); i < calendarEndDay; i++) {

			calendarList.add(blankCalendar);
		}

		return calendarList;
	}

	//カレンダー検索（年月、顧客ID、社員ID）
	public Map<String, Object> searchCalendar(String yearMonth, Integer clientId, Integer employeeId) {

		Map<String, Object> map = calendarDao.searchCalendar(yearMonth, clientId, employeeId);

		return map;
	}

	//カレンダー登録
	public void registCalendar(CalendarListParam calendarListParam, Integer clientId, int monthlyHolidays,
			String createdUser, String updatedUser) {

		calendarDao.registCalendar(calendarListParam, clientId, monthlyHolidays, createdUser, updatedUser);
	}

	//最大シーケンスIDを取得
	public int getMaxParentId() {

		int result = calendarDao.getMaxParentId();

		return result;
	}

	//カレンダー詳細登録
	public void registCalendarDetail(Integer parentSeqId, CalendarData calendarData, String yearMonth,
			String createdUser, String updatedUser) {

		calendarDao.registCalendarDetail(parentSeqId, calendarData, yearMonth, createdUser, updatedUser);

	}

	//カレンダー削除
	public int deleteCalendar(String[] calendarSeqIdIndex, String updatedUser) {

		int result = calendarDao.deleteCalendar(calendarSeqIdIndex, updatedUser);

		return result;
	}

	//カレンダー情報詰め替え
	public CalendarListParam settingCalendarParam(CalendarListParam calendarListParam, Integer seqId) {

		Map<String, Object> calendarMap = calendarDao.searchCalendar(seqId);

		for (String key : calendarMap.keySet()) {

			try {

				//switch文でMapの中身をCalendarDataへ詰め替えをおこなう。
				switch (key) {

				case "seq_id":
					calendarListParam.setCalendarSeqId(seqId);
					break;

				case "client_id":
					calendarListParam.setClientId((int) calendarMap.get(key));
					break;

				case "client_name":
					calendarListParam.setClientName(calendarMap.get(key).toString());
					break;

				case "employee_id":
					calendarListParam.setEmployeeId((int) calendarMap.get(key));
					break;

				case "employee_name":
					calendarListParam.setEmployeeName(calendarMap.get(key).toString());
					break;

				case "year_month":
					String strYearMonth = calendarMap.get(key).toString();
					calendarListParam.setCalendarYear(strYearMonth.substring(0, 4));
					calendarListParam.setCalendarMonth(strYearMonth.substring(5, 7));
					break;

				case "year_comment":
					calendarListParam.setAllYearRoundComment(calendarMap.get(key).toString());
					break;

				}

			} catch (NullPointerException e) {
				//nullを検知したらこのループを抜けるためだけのコード。なので処理なし。
			}
		}

		return calendarListParam;
	}

	//calendarDataに表示情報を詰める
	public List<CalendarData> settingEditCalendarList(
			Integer parentSeqId,
			List<CalendarData> calendarDataList,
			String strYearMonth) {

		for (CalendarData calendarData : calendarDataList) {

			if (calendarData.getDay() != null) {

				//桁数調整
				String strDay = String.format("%02d", calendarData.getDay());
				//日にちまで入った日付を作成
				String strYerMonthDay = strYearMonth + "-" + strDay;

				Map<String, Object> detailMap = calendarDao.getCalendarDetailYearMonth(parentSeqId, strYerMonthDay);

				for (String key : detailMap.keySet()) {

					try {

						//switch文でMapの中身をCalendarDataへ詰め替えをおこなう。
						switch (key) {

						case "seq_id":
							Integer seqId = (int) detailMap.get(key);
							calendarData.setSeqId(seqId);
							break;

						case "holiday_flg":
							boolean holidayFlg = (boolean) detailMap.get(key);
							calendarData.setHolidayFlg(holidayFlg);
							break;

						case "comment":
							String comment = detailMap.get(key).toString();
							calendarData.setComment(comment);
							break;

						}

					} catch (NullPointerException e) {
						//nullを検知したらこのループを抜けるためだけのコード。なので処理なし。
					}
				}

			}

		}

		return calendarDataList;
	}

	//	public CalendarData changeCalendarData(Map<String, Object> detailMap) {
	//
	//
	//		
	//
	//		// クエリを実行
	//		Map<String, Object> calendarDetailMap = jdbcTemplate.queryForMap(sql, param);
	//
	//		// 取得したマップを返す
	//		return calendarDetailMap;
	//	}

	/**
	 * 指定されたカレンダーを更新するメソッドを呼び出す。
	 *
	 */
	public void updateCalendar(CalendarListParam calendarListParam, int monthlyHolidays, String updatedUser) {

		calendarDao.updateCalendar(calendarListParam, monthlyHolidays, updatedUser);

	}

	public void updateCalendarDetail(CalendarData calendarData, Integer parentSeqId, String yearMonth,
			String updatedUser) {

		calendarDao.updateCalendarDetail(calendarData, parentSeqId, yearMonth, updatedUser);

	}

	//顧客検索
	public Map<String, Object> searchClient(String clientName) {

		Map<String, Object> map = calendarDao.searchClient(clientName);

		return map;
	}

	public List<Map<String, Object>> getSearchCalendarList1(Integer employeeId, String employeeName,
			String clientName, String searchStartYearMonth, String searchEndYearMonth, int start) {

		List<Map<String, Object>> list = calendarDao.getSearchCalendarList1(employeeId, employeeName, clientName,
				searchStartYearMonth, searchEndYearMonth, start);
		list = settingCalendarList(list);

		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList2(Integer employeeId, String employeeName,
			String clientName, String searchStartYearMonth, int start) {

		List<Map<String, Object>> list = calendarDao.getSearchCalendarList2(employeeId, employeeName, clientName,
				searchStartYearMonth, start);
		list = settingCalendarList(list);

		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList3(Integer employeeId, String employeeName,
			String clientName, String searchEndYearMonth, int start) {

		List<Map<String, Object>> list = calendarDao.getSearchCalendarList3(employeeId, employeeName, clientName,
				searchEndYearMonth, start);
		list = settingCalendarList(list);

		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList4(Integer employeeId, String employeeName,
			String searchStartYearMonth, String searchEndYearMonth, int start) {

		List<Map<String, Object>> list = calendarDao.getSearchCalendarList4(employeeId, employeeName,
				searchStartYearMonth, searchStartYearMonth, start);
		list = settingCalendarList(list);

		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList5(Integer employeeId, String employeeName,
			String clientName, int start) {

		List<Map<String, Object>> list = calendarDao.getSearchCalendarList5(employeeId, employeeName,
				clientName, start);
		list = settingCalendarList(list);

		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList6(Integer employeeId, String employeeName,
			String searchStartYearMonth, int start) {

		List<Map<String, Object>> list = calendarDao.getSearchCalendarList6(employeeId, employeeName,
				searchStartYearMonth, start);
		list = settingCalendarList(list);

		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList7(Integer employeeId, String employeeName,
			String searchEndYearMonth, int start) {

		List<Map<String, Object>> list = calendarDao.getSearchCalendarList7(employeeId, employeeName,
				searchEndYearMonth, start);
		list = settingCalendarList(list);

		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList8(Integer employeeId, String employeeName,
			int start) {

		List<Map<String, Object>> list = calendarDao.getSearchCalendarList8(employeeId, employeeName, start);
		list = settingCalendarList(list);
		
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList9(String clientName, String searchStartYearMonth,
			String searchEndYearMonth, int start) {

		List<Map<String, Object>> list = calendarDao.getSearchCalendarList9(clientName, searchStartYearMonth,
				searchEndYearMonth, start);
		list = settingCalendarList(list);

		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList10(String clientName, String searchStartYearMonth,
			int start) {

		List<Map<String, Object>> list = calendarDao.getSearchCalendarList10(clientName, searchStartYearMonth,
				start);
		list = settingCalendarList(list);

		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList11(String clientName, String searchEndYearMonth,
			int start) {

		List<Map<String, Object>> list = calendarDao.getSearchCalendarList11(clientName, searchEndYearMonth,
				start);
		list = settingCalendarList(list);

		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList12(String clientName, int start) {

		List<Map<String, Object>> list = calendarDao.getSearchCalendarList12(clientName, start);
		list = settingCalendarList(list);
		
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList13(String searchStartYearMonth, String searchEndYearMonth,
			int start) {

		List<Map<String, Object>> list = calendarDao.getSearchCalendarList13(searchStartYearMonth, searchEndYearMonth,
				start);
		list = settingCalendarList(list);

		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList14(String searchStartYearMonth, int start) {

		List<Map<String, Object>> list = calendarDao.getSearchCalendarList14(searchStartYearMonth, start);
		list = settingCalendarList(list);
		
		return list;
	}

	public List<Map<String, Object>> getSearchCalendarList15(String searchEndYearMonth, int start) {

		List<Map<String, Object>> list = calendarDao.getSearchCalendarList15(searchEndYearMonth, start);
		list = settingCalendarList(list);
		
		return list;
	}

	public List<Map<String, Object>> settingCalendarList(List<Map<String, Object>> beforeList) {

		if (beforeList.size() != 0) {

			for (Map<String, Object> calendarMap : beforeList) {

				String strYear = calendarMap.get("year_month").toString();
				strYear = strYear.substring(0, strYear.indexOf("-"));
				int calendarYear = Integer.parseInt(strYear);
				int clientId = (int) calendarMap.get("client_id");
				Integer employeeId = null;
				if (calendarMap.get("employee_id") != null) {
					employeeId = (int) calendarMap.get("employee_id");
				}

				Timestamp timestampCreate = (Timestamp) calendarMap.get("created_at");
				Timestamp timestampUpdate = (Timestamp) calendarMap.get("updated_at");
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
				String strCreatedAt = sdf.format(timestampCreate);
				String strUpdatedAt = sdf.format(timestampCreate);

				calendarMap.put("holidaysInTheYear",
						calendarDao.getholidaysInTheYear(calendarYear, clientId, employeeId));
				calendarMap.put("strCreatedAt", strCreatedAt);
				calendarMap.put("strUpdatedAt", strUpdatedAt);
			}
		}
		
		return beforeList;

	}

}

package com.nexus.whc.models;

import java.util.List;

public class CalendarIndexForm {
	
	//
    private List<CalendarData> calendarDetailFormList;

}

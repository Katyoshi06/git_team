package com.nexus.whc.models;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class CalendarListParam implements Serializable {

	/**
	 * カレンダー情報リスト
	 */
	@Valid
	private List<CalendarData> calendarDataList;

	//ページ表示ステータス
	private String eventStatus;
	//カレンダーシーケンスID
	private Integer calendarSeqId;
	//顧客ID
	private Integer clientId;
	//顧客名
	@NotEmpty(message = "顧客名は必ず入力してください。")
	private String clientName;
	//社員ID
	private Integer employeeId;
	//社員名
	private String employeeName;
	//カレンダー表示年
	@NotEmpty(message = "年月は必ず入力してください。")
	private String calendarYear;
	//カレンダー表示月
	@NotEmpty(message = "年月は必ず入力してください。")
	private String calendarMonth;
	//通年備考
	private String allYearRoundComment;
	//通年備考
	private String fromYearMonth;
	//通年備考
	private String toYearMonth;

}

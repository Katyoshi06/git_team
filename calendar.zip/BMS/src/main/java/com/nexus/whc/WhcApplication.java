package com.nexus.whc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhcApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhcApplication.class, args);
	}

}

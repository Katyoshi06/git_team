package com.nexus.whc.services;

import org.springframework.stereotype.Service;

import com.nexus.whc.repository.NationalHolidayDao;

/*
 * TopService.java
 * 
 * TopServiceクラス
 */

/*
 * Serviceクラス
 */

@Service
public class NationalHolidayService {
	private final NationalHolidayDao nationalHolidayDao;

	public NationalHolidayService(NationalHolidayDao nationalHolidayDao) {
		this.nationalHolidayDao = nationalHolidayDao;
	}
	
	public boolean isNationalHoliday(String yearMonthDay) {
		
		boolean nationalHolidayFlg = nationalHolidayDao.isNationalHoliday(yearMonthDay);

		
		return nationalHolidayFlg;
	}

}

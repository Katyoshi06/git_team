package com.nexus.whc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ClientController {
	
	@GetMapping("/SMSCL001")
	public String calendarList(Model model) {
		return "SMSCL001";
	}

}

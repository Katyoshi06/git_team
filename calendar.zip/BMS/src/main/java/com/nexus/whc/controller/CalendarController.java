package com.nexus.whc.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.nexus.whc.models.CalendarData;
import com.nexus.whc.models.CalendarListParam;
import com.nexus.whc.models.CalendarSearchForm;
import com.nexus.whc.services.CalendarService;
import com.nexus.whc.services.NationalHolidayService;

@Controller
public class CalendarController {

	@Autowired
	CalendarService calendarService;

	@Autowired
	NationalHolidayService nationalHolidayService;

	@GetMapping("/SMSCD001")
	public String calendarList(
			@RequestParam(name = "page", required = false) Integer num,
			@RequestParam(name = "pageStatus", required = false) Integer pageStatus,
			Model model) {

		Integer start;
		List<Map<String, Object>> maxList = calendarService.getAllCalendar();
		Integer maxSize = maxList.size();
		Integer maxPage;
		int viewPage = 20;

		if (maxSize % (double) viewPage == 0) {
			maxPage = maxSize / viewPage;
		} else {
			maxPage = maxSize / viewPage + 1;
		}

		if (num == null) {
			num = 0;

		} else if (num != null) {

			if (pageStatus == null) {

			} else if (pageStatus == 1) {
				num -= 1;

			} else if (pageStatus == 2) {
				num += 1;
			}
		}

		start = num * viewPage;

		CalendarSearchForm calendarSearchForm = new CalendarSearchForm();

		List<Map<String, Object>> list = calendarService.getCalendar20(start);

		model.addAttribute("calendar_list", list);
		model.addAttribute("searchForm", calendarSearchForm);
		model.addAttribute("page", num);
		model.addAttribute("maxPage", maxPage);

		return "SMSCD001";
	}

	@PostMapping("/search")
	public String calendarSearch(
			@ModelAttribute CalendarSearchForm calendarSearchForm,
			@RequestParam(name = "page", required = false) Integer num,
			@RequestParam(name = "pageStatus", required = false) Integer pageStatus,
			@RequestParam(name = "searchForm", required = false) CalendarSearchForm searchForm,

			Model model) {

		List<Map<String, Object>> list = null;
		if (num == null) {
			num = 0;
		}

		Integer employeeId = calendarSearchForm.getEmployeeId();
		String employeeName = calendarSearchForm.getEmployeeName();
		String clientName = calendarSearchForm.getClientName();
		Integer yearMonthOption = calendarSearchForm.getYearMonthOption();
		String searchStartYearMonth = calendarSearchForm.getSearchStartYearMonth();
		String searchEndYearMonth = calendarSearchForm.getSearchEndYearMonth();

//		if (searchForm != null) {
//			if (calendarSearchForm.getEmployeeId() != null) {
//				employeeId = searchForm.getEmployeeId();
//			}
//			if (calendarSearchForm.getEmployeeName().equals("")) {
//				employeeName = searchForm.getEmployeeName();
//			}
//			if (calendarSearchForm.getClientName().equals("")) {
//				clientName = searchForm.getClientName();
//			}
//
//			yearMonthOption = searchForm.getYearMonthOption();
//
//			if (calendarSearchForm.getSearchStartYearMonth().equals("")) {
//				searchStartYearMonth = searchForm.getSearchStartYearMonth();
//			}
//			if (calendarSearchForm.getSearchEndYearMonth().equals("")) {
//				searchEndYearMonth = searchForm.getSearchEndYearMonth();
//			}
//		}

		if (yearMonthOption == 1 && !searchStartYearMonth.equals("") && !searchEndYearMonth.equals("")) {

			searchStartYearMonth = searchStartYearMonth.substring(0, 5) + "01-01";
			searchEndYearMonth = searchStartYearMonth.substring(0, 5) + "12-31";
		}

		if (employeeId != null) {

			if (!(clientName.equals("")) && !(searchStartYearMonth.equals("")) && !(searchEndYearMonth.equals(""))) {

				list = calendarService.getSearchCalendarList1(employeeId, employeeName, clientName,
						searchStartYearMonth, searchEndYearMonth, num);

			} else if (!(clientName.equals("")) && !(searchStartYearMonth.equals(""))) {

				list = calendarService.getSearchCalendarList2(employeeId, employeeName, clientName,
						searchStartYearMonth, num);
				;

			} else if (!(clientName.equals("")) && !(searchEndYearMonth.equals(""))) {

				list = calendarService.getSearchCalendarList3(employeeId, employeeName, clientName, searchEndYearMonth,
						num);

			} else if (!searchStartYearMonth.equals("") && !searchEndYearMonth.equals("")) {

				list = calendarService.getSearchCalendarList4(employeeId, employeeName, searchStartYearMonth,
						searchEndYearMonth, num);

			} else if (!clientName.equals("")) {

				list = calendarService.getSearchCalendarList5(employeeId, employeeName, clientName, num);

			} else if (!searchStartYearMonth.equals("")) {

				list = calendarService.getSearchCalendarList6(employeeId, employeeName, searchStartYearMonth, num);

			} else if (!searchEndYearMonth.equals("")) {

				list = calendarService.getSearchCalendarList7(employeeId, employeeName, searchEndYearMonth, num);

			} else {

				list = calendarService.getSearchCalendarList8(employeeId, employeeName, num);

			}

		} else if (!clientName.equals("")) {

			if (!searchStartYearMonth.equals("") && !searchEndYearMonth.equals("")) {

				list = calendarService.getSearchCalendarList9(clientName, searchStartYearMonth, searchEndYearMonth,
						num);

			} else if (!searchStartYearMonth.equals("")) {

				list = calendarService.getSearchCalendarList10(clientName, searchStartYearMonth, num);

			} else if (!searchEndYearMonth.equals("")) {

				list = calendarService.getSearchCalendarList11(clientName, searchEndYearMonth, num);

			} else {

				list = calendarService.getSearchCalendarList12(clientName, num);

			}

		} else if (!searchStartYearMonth.equals("")) {

			if (!searchEndYearMonth.equals("")) {

				list = calendarService.getSearchCalendarList13(searchStartYearMonth, searchEndYearMonth, num);

			} else {

				list = calendarService.getSearchCalendarList14(searchStartYearMonth, num);

			}

		} else if (!searchEndYearMonth.equals("")) {

			list = calendarService.getSearchCalendarList15(searchEndYearMonth, num);

		}

		model.addAttribute("calendar_list", list);
		model.addAttribute("searchForm", calendarSearchForm);

		return "SMSCD001";
	}

	@PostMapping("/SMSCD001")
	public String calendarDelete(
			@RequestParam(name = "selectCheck", required = false) String[] calendarSeqId,
			RedirectAttributes attr,
			Model model) {

		// 画面遷移先を報告書一覧画面へのリダイレクトに指定
		String res = "redirect:/SMSCD001";
		// 削除件数
		int deleteResult;

		//エラーメッセージ
		String message = new String();

		if (calendarSeqId == null) {
			//エラーメッセージ(仮)
			message = "削除カレンダー未選択エラー";
		} else {

			//★論理削除を実行
			deleteResult = calendarService.deleteCalendar(calendarSeqId, "nexsus01");
			message = deleteResult + "件削除しました。";
		}

		attr.addFlashAttribute("message", message);

		return res;
	}

	@GetMapping("/SMSCD002")
	public String calendarGetRegist(
			@ModelAttribute CalendarListParam calendarListParam,
			@RequestParam(name = "selectCheck", required = false) String[] calendarSeqIdIndex,
			//			@RequestParam(name = "eventStatus", required = false) String eventStatus,
			//			@RequestParam(name = "calendarSeqId", required = false) String calendarSeqId,
			//			@RequestParam(name = "calendarYear", required = false) String calendarYear,
			//			@RequestParam(name = "calendarMonth", required = false) String calendarMonth,
			@RequestParam(name = "seqId", required = false) Integer calendarSeqId,
			@RequestParam(name = "pagestatus", required = false) Integer pagestatus,
			RedirectAttributes attr,
			Model model) {

		//redirect用処理
		if (calendarListParam.getEventStatus() != null && pagestatus == null) {
			if (calendarListParam.getEventStatus().equals("create")) {
				return "SMSCD002";
			}
		}

		//formクラスの中身を取り出す
		String eventStatus = calendarListParam.getEventStatus();
		if (calendarSeqId == null) {
			calendarSeqId = calendarListParam.getCalendarSeqId();
		}
		String calendarYear = calendarListParam.getCalendarYear();
		String calendarMonth = calendarListParam.getCalendarMonth();

		//これから使う共通の変数の宣言
		int intCalendarYear = 0;
		int intCalendarMonth = 0;
		//yyyy/MM/dd　の形に変換したうえでString に変換
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String strYearMonth = null;
		String strYear = null;//String　年
		String strMonth = null;//String
		Calendar cl = null;

		List<CalendarData> calendarDataList = new ArrayList<CalendarData>();

		//選択行コピー処理
		if (calendarSeqIdIndex != null) {
			try {
				if (calendarSeqIdIndex.length > 1) {

					attr.addFlashAttribute("message", "過剰選択エラー");
					return "redirect:/SMSCD001";
				}
			} catch (NullPointerException e) {

				attr.addFlashAttribute("message", "未選択エラー");
				return "redirect:/SMSCD001";
			}

			calendarSeqId = Integer.valueOf(calendarSeqIdIndex[0]);

			calendarListParam = calendarService.settingCalendarParam(calendarListParam, calendarSeqId);

			strYear = String.valueOf(calendarListParam.getCalendarYear());
			strMonth = String.valueOf(calendarListParam.getCalendarMonth());
			strYearMonth = strYear + "-" + strMonth + "-01";

			intCalendarYear = Integer.parseInt(strYear);
			intCalendarMonth = Integer.parseInt(strMonth);

			//表示年月に合わせた空白入りList<CalendarData>を出力
			calendarDataList = settingBlankCalendar(intCalendarYear, intCalendarMonth);

			calendarDataList = calendarService.settingEditCalendarList(calendarSeqId, calendarDataList,
					strYear + "-" + strMonth);

			//画面出力用クラスに詰める
			calendarListParam.setEventStatus("create");
			calendarListParam.setCalendarDataList(calendarDataList);
			model.addAttribute("calendarListParam", calendarListParam);

			return "SMSCD002";

		}

		//表示年月の調整
		if ((calendarYear != null && calendarMonth != null)) {

			intCalendarYear = Integer.parseInt(calendarYear);
			intCalendarMonth = Integer.parseInt(calendarMonth);

			if (pagestatus != null) {
				if (pagestatus == 1) {
					if (intCalendarMonth == 1) {
						intCalendarYear--;
						intCalendarMonth = 12;
					} else {
						intCalendarMonth--;
					}

				} else if (pagestatus == 2) {
					if (intCalendarMonth == 12) {
						intCalendarYear++;
						intCalendarMonth = 1;
					} else {
						intCalendarMonth++;
					}
				}
			}

			strYear = String.valueOf(intCalendarYear);
			strMonth = String.valueOf(intCalendarMonth);
			strYearMonth = strYear + "-" + strMonth + "-01";

		} else if (calendarSeqId != null) {

			calendarListParam = calendarService.settingCalendarParam(calendarListParam, calendarSeqId);

			strYear = String.valueOf(calendarListParam.getCalendarYear());
			strMonth = String.valueOf(calendarListParam.getCalendarMonth());
			strYearMonth = strYear + "-" + strMonth + "-01";

			intCalendarYear = Integer.parseInt(strYear);
			intCalendarMonth = Integer.parseInt(strMonth);

		} else {

			calendarListParam.setEventStatus("create");
			model.addAttribute("calendarListParam", calendarListParam);

			return "SMSCD002";

		}

		//表示年月に合わせた空白入りList<CalendarData>を出力
		calendarDataList = settingBlankCalendar(intCalendarYear, intCalendarMonth);

		//編集処理か否か
		if (calendarService.searchCalendar(strYearMonth, calendarListParam.getClientId(),
				calendarListParam.getEmployeeId()) != null) {

			calendarDataList = calendarService.settingEditCalendarList(calendarSeqId, calendarDataList,
					strYear + "-" + strMonth);
			calendarListParam.setEventStatus("update");

		} else {
			calendarListParam.setCalendarYear(strYear);
			calendarListParam.setCalendarMonth(strMonth);
			calendarListParam.setEventStatus("create");
		}

		//画面出力用クラスに詰める
		calendarListParam.setCalendarDataList(calendarDataList);

		model.addAttribute("calendarListParam", calendarListParam);

		return "SMSCD002";
	}

	@PostMapping("/SMSCD002")
	public String calendarPostRegist(
			@Validated @ModelAttribute CalendarListParam calendarListParam,
			BindingResult result,
			RedirectAttributes attr,
			Model model) {

		if (result.hasErrors()) {
			attr.addFlashAttribute("message", "未入力エラー");
			attr.addFlashAttribute("calendarListParam", calendarListParam);
			return "redirect:/SMSCD002";
		}

		int redirectSeqId = 0;
		//フォームクラスの中身を取り出す。
		List<CalendarData> calendarDataList = calendarListParam.getCalendarDataList();
		String yearMonthDay = calendarListParam.getCalendarYear() + "-" + calendarListParam.getCalendarMonth() + "-01";
		int monthlyHolidays = 0;

		if (calendarListParam.getCalendarSeqId() != null) {
			//月間休日数
			monthlyHolidays = getMonthlyHolidays(calendarDataList);
		}

		//顧客情報がDBに存在するか。
		Map<String, Object> searchClientMap = calendarService.searchClient(calendarListParam.getClientName());
		if (searchClientMap == null) {
			attr.addFlashAttribute("message", "顧客不在");
			attr.addFlashAttribute("calendarListParam", calendarListParam);
			return "redirect:/SMSCD002";
		}

		Integer clientId = (Integer) searchClientMap.get("client_id");
		Map<String, Object> calendarMap = calendarService.searchCalendar(yearMonthDay, clientId,
				calendarListParam.getEmployeeId());

		//使用メソッドの選択分岐
		if (calendarMap == null && calendarListParam.getEventStatus().equals("create")) {

			int intCalendarYear = Integer.valueOf(calendarListParam.getCalendarYear());
			int intCalendarMonth = Integer.valueOf(calendarListParam.getCalendarMonth());

			calendarDataList = settingBlankCalendar(intCalendarYear, intCalendarMonth);
			calendarListParam.setCalendarDataList(calendarDataList);
			monthlyHolidays = getMonthlyHolidays(calendarDataList);

			calendarService.registCalendar(calendarListParam, clientId, monthlyHolidays, "nexus01", "nexus01");

			int parentId = calendarService.getMaxParentId();
			String yearMonth = yearMonthDay.substring(0, yearMonthDay.length() - 3);

			for (CalendarData calendarData : calendarDataList) {

				if (calendarData.getDay() != null) {

					calendarService.registCalendarDetail(parentId, calendarData, yearMonth, "nexus01", "nexus01");

				}
			}

			return "redirect:/SMSCD002?seqId=" + parentId;

		} else if (calendarMap != null && calendarListParam.getEventStatus().equals("create")) {

			redirectSeqId = calendarService.getMaxParentId();
			//カレンダー登録済みエラー
			attr.addFlashAttribute("message", "カレンダー登録済みエラー");
			attr.addFlashAttribute("calendarListParam", calendarListParam);

			return "redirect:/SMSCD002";

		} else if (calendarMap != null && calendarListParam.getEventStatus().equals("update")) {

			String yearMonth = yearMonthDay.substring(0, yearMonthDay.length() - 3);

			calendarService.updateCalendar(calendarListParam, monthlyHolidays, "nexus01");

			for (CalendarData calendarData : calendarDataList) {

				if (calendarData.getDay() != null) {

					calendarService.updateCalendarDetail(calendarData, calendarListParam.getCalendarSeqId(),
							yearMonth, "nexus01");

				}
			}

			redirectSeqId = calendarListParam.getCalendarSeqId();

		}

		return "redirect:/SMSCD002?seqId=" + redirectSeqId;
	}

	@PostMapping("/accordingToTheCalendar")
	public String calendarRegistaccordingToTheCalendar(
			@Validated @ModelAttribute CalendarListParam calendarListParam,
			BindingResult result,
			//			@RequestParam(name = "fromYearMonth", required = false) String fromYearMonth,
			//			@RequestParam(name = "toYearMonth", required = false) String toYearMonth,
			RedirectAttributes attr,
			Model model) {

		String fromYearMonth = calendarListParam.getFromYearMonth();
		String toYearMonth = calendarListParam.getToYearMonth();

		List<CalendarData> calendarDataList = new ArrayList<CalendarData>();

		if (calendarListParam.getClientName() == null || fromYearMonth == null || toYearMonth == null) {
			attr.addFlashAttribute("message", "未入力エラー");
			attr.addFlashAttribute("calendarListParam", calendarListParam);
			return "redirect:/SMSCD002";
		}

		//顧客情報がDBに存在するか。
		Map<String, Object> searchClientMap = calendarService.searchClient(calendarListParam.getClientName());
		if (searchClientMap == null) {
			attr.addFlashAttribute("message", "顧客不在");
			attr.addFlashAttribute("calendarListParam", calendarListParam);
			return "redirect:/SMSCD002";
		}

		//顧客ID
		Integer clientId = (Integer) searchClientMap.get("client_id");

		//メソッド代入用変数
		int intCalendarYear = 0;
		int intCalendarMonth = 0;

		//年、月をint型に変換
		String strFromYear = fromYearMonth.substring(0, 4);
		String strFromMonth = fromYearMonth.substring(5, fromYearMonth.length());
		int intFromYear = Integer.valueOf(strFromYear);
		int intFromMonth = Integer.valueOf(strFromMonth);

		String strToYear = toYearMonth.substring(0, 4);
		String strToMonth = toYearMonth.substring(5, toYearMonth.length());
		int intToYear = Integer.valueOf(strToYear);
		int intToMonth = Integer.valueOf(strToMonth);

		if (intFromYear >= intToYear && intFromMonth > intToMonth) {
			attr.addFlashAttribute("message", "入力日付不正");
			attr.addFlashAttribute("calendarListParam", calendarListParam);
			return "redirect:/SMSCD002";
		}

		int monthlyHolidays = 0; //月間休日
		Date referenceDateFrom = null;
		Date referenceDateTo = null;

		do {
			intCalendarYear = intFromYear;
			intCalendarMonth = intFromMonth;
			String strcalendarYear = String.valueOf(intFromYear);
			String strcalendarMonth = String.valueOf(intFromMonth);
			calendarListParam.setCalendarYear(strcalendarYear);
			calendarListParam.setCalendarMonth(strcalendarMonth);

			//表示年月に合わせた空白入りList<CalendarData>を出力
			calendarDataList = settingBlankCalendar(intCalendarYear, intCalendarMonth);
			calendarListParam.setCalendarDataList(calendarDataList);
			monthlyHolidays = getMonthlyHolidays(calendarDataList);

			calendarService.registCalendar(calendarListParam, clientId, monthlyHolidays, "nexus01", "nexus01");

			int parentId = calendarService.getMaxParentId();
			String yearMonth = strcalendarYear + "-" + strcalendarMonth;

			for (CalendarData calendarData : calendarDataList) {

				if (calendarData.getDay() != null) {

					System.out.println(calendarData.getComment());
					calendarService.registCalendarDetail(parentId, calendarData, yearMonth, "nexus01", "nexus01");

				}
			}

			++intFromMonth;
			if (intFromMonth > 12) {
				intFromMonth = 1;
				++intFromYear;
			}

			strFromYear = String.valueOf(intFromYear);
			strFromMonth = String.valueOf(intFromMonth);
			strToYear = String.valueOf(intToYear);
			strToMonth = String.valueOf(intToMonth);

			SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");

			try {
				referenceDateFrom = sf.parse(strFromYear + "-" + strFromMonth + "-01");
				referenceDateTo = sf.parse(strToYear + "-" + strToMonth + "-01");

			} catch (Exception e) {
				//例外は基本起きない想定
			}

		} while (referenceDateFrom.compareTo(referenceDateTo) < 1);

		return "redirect:/SMSCD002?seqId=";
	}

	public int getMonthlyHolidays(List<CalendarData> calendarDataList) {
		int monthlyHoliday = 0;

		for (CalendarData calendarData : calendarDataList) {

			if (calendarData.getDay() != null && calendarData.isHolidayFlg()) {

				monthlyHoliday++;
			}
		}

		return monthlyHoliday;
	}

	public List<CalendarData> settingBlankCalendar(int intCalendarYear, int intCalendarMonth) {

		String strYear = String.valueOf(intCalendarYear);
		String strMonth = String.format("%02d", intCalendarMonth);
		String strYearMonthDay = strYear + "-" + strMonth + "-01";

		//カレンダー表示
		int[] month = new int[] { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31, 29 };
		int calendarMonthIndex = intCalendarMonth;

		//うるう年判定
		if (intCalendarYear % 4 == 0 && intCalendarMonth == 2) {
			calendarMonthIndex = 13;
		}

		List<CalendarData> blankCalendarList = new ArrayList<CalendarData>();

		//フォーマッター
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
		//基準日（月初日）
		Date referenceDate = null;

		for (int i = 0; i < month[calendarMonthIndex]; i++) {

			int day = i + 1;
			String yearMonthDay = strYear + "-" + strMonth + "-" + day;
			CalendarData calendarData = new CalendarData();

			try {
				referenceDate = sf.parse(yearMonthDay);
			} catch (Exception e) {
				//例外は基本起きない想定
			}
			Calendar cal = Calendar.getInstance();
			// Dateをカレンダーへ
			cal.setTime(referenceDate);
			//カレンダー表示時の補正値 (1始まりのため、-1する)
			int correctionValue = cal.get(Calendar.DAY_OF_WEEK) - 1;
			
			

			if (correctionValue == 0 || correctionValue == 6
					|| nationalHolidayService.isNationalHoliday(yearMonthDay)) {

				calendarData.setHolidayFlg(true);

			}
			calendarData.setWeekStatus(correctionValue);
			calendarData.setDay(day);
			blankCalendarList.add(calendarData);
		}
		blankCalendarList = calendarService.settingCalendar(strYearMonthDay, blankCalendarList);

		return blankCalendarList;
	}

	//休日設定メソッド
	public List<CalendarData> settingHolidayr(List<CalendarData> beforeListh, String yearMonth) {

		List<CalendarData> list = null;

		return list;
	}

}

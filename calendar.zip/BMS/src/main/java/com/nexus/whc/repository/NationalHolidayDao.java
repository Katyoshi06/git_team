package com.nexus.whc.repository;

import java.util.List;
import java.util.Map;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/*
 * TopRepository.java
 * 
 * TopRepositoryクラス
 */

/*
 * Repositoryクラス
 */

@Repository
public class NationalHolidayDao {
	private final JdbcTemplate jdbcTemplate;

	public NationalHolidayDao(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<Map<String, Object>> searchAll() {

		// SQL文作成
		String sql = "SELECT * from m_national_holiday";

		// クエリを実行
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);

		// 取得したリストを返す
		return list;
	}

	public boolean isNationalHoliday(String yearMonthDay) {

		boolean holidayFlg = true;

		// SQL文作成
		String sql = "SELECT * from m_national_holiday "
				+ "WHERE m_national_holiday.date = ? "
				+ "AND delete_flg != 1";
		
		//?の箇所を置換するデータの配列を定義
				Object[] param = { yearMonthDay };

		try {
			// クエリを実行
			Map<String, Object> map = jdbcTemplate.queryForMap(sql ,param);
		} catch (EmptyResultDataAccessException e) {
			//Mapの中身が空の場合のみfalseを代入する
			holidayFlg = false;
		}

		// 取得したリストを返す
		return holidayFlg;
	}

}

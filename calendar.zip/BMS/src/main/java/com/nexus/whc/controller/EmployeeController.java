package com.nexus.whc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class EmployeeController {
	
	@GetMapping("/SMSEM001")
	public String employeeList(Model model) {
		return "SMSEM001";
	}
}

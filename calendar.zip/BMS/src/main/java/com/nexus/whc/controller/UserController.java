package com.nexus.whc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UserController {
	
	@GetMapping("/SMSUS001")
	public String userList(Model model) {
		return "SMSUS001";
	}

}

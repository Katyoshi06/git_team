package com.nexus.whc.models;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class CalendarSearchForm {

	//社員ID
	private Integer employeeId;
	//社員名
	private String employeeName;
	//顧客名
	private String clientName;
	//年/年月検索オプション
	private Integer yearMonthOption;
	//検索開始年月
	private String searchStartYearMonth;
	//検索終了年月
	private String searchEndYearMonth;

}

$('input[id=lefile]').change(function() {
    $('#photoCover').val($(this).val());
  });
function inputChange(element){
	element.setAttribute("title",element.value);
}
package jp.co.nexus;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhcApplicationTests {

}
